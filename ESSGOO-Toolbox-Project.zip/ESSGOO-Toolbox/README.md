# ESSGOO Toolbox

Android app for an ESSGOO/MT8163 head unit (Android 9 / API 28), designed to run without root. Includes a dashboard, system report, shortcuts to common head-unit apps/settings, and an experimental Bluetooth Classic SPP ELM327 OBD-II client.

## Build APK on GitHub (no PC needed after upload)
1. Create a new GitHub repository.
2. Upload the contents of this folder, including `.github/workflows/android.yml`, to the repository's `main` branch.
3. Open **Actions** and allow workflows if GitHub asks.
4. Open **Build ESSGOO Toolbox APK**, select the newest successful run, then download the `ESSGOO-Toolbox-debug-apk` artifact.
5. Extract the downloaded artifact ZIP; install `app-debug.apk` on the head unit. If Android blocks installation, allow installs from the browser/file manager you used.

The workflow builds with JDK 17, Gradle 8.9 and Android Gradle Plugin 8.7.3. Target SDK is 28 for compatibility with Android 9. The APK is a debug build and is not Play Store-signed.

## Features
- Automotive dark UI designed for a 1280x720 landscape screen.
- Device/build/ABI/kernel information and shareable diagnostic report.
- Shortcuts to ZLINK, DVR, DSP and Android settings when those packages exist.
- Bluetooth Classic SPP connection to already-paired ELM327 adapters; tries RPM (010C), coolant temperature (0105), ECU voltage (0142), DTC read (03) and user-confirmed DTC clear (04).
- Graceful unavailable/error states instead of invented values.

## Important limitations
- The app does **not** flash or modify MCU firmware.
- The GitHub firmware repository describes the MCU protocol, but this alone does not grant an ordinary Android app access to the serial device. Direct MCU UART probing is intentionally not attempted: vendor services/permissions/device nodes differ by firmware and incorrect commands could disrupt power management.
- OBD-II features require a compatible paired Bluetooth Classic SPP adapter and ECU support. BLE-only adapters may not work. Some ELM327 clones mishandle commands/PIDs.
- `0142` is ECU control-module voltage, not a guaranteed reading of the head unit's own supply. The vehicle-voltage value shown by the stock ESSGOO status bar may come from a vendor-only service.
- Android settings screens and installed package names vary by firmware. The app reports when a target app is missing.
- This is a first implementation; it must be built by GitHub Actions and tested on the actual head unit. No claim is made that every hardware-specific function works without device validation.

## Project structure
- `app/` Android Java app
- `.github/workflows/android.yml` GitHub Actions build and APK artifact upload
